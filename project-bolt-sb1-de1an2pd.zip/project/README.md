# RAHAT RUNS - 2D Platformer Game

A side-scrolling platformer game where Rahat runs and jumps through various obstacles in a vibrant, colorful world.

## Game Features

- Smooth running mechanics with variable speed
- Responsive jumping system with double-jump capability
- Various obstacles including gaps, hurdles, floating barriers, and platforms
- Collectible power-ups for bonus points
- Day/night cycle with dynamic background elements
- Progressive difficulty scaling as you advance
- Local leaderboard to track high scores
- Responsive controls for both desktop and mobile

## Controls

### Desktop
- **Left/Right**: Arrow Keys or A/D
- **Jump**: Space, Up Arrow, or W
- **Slide**: Down Arrow or S

### Mobile
- **Move**: Tap left/right side of the screen
- **Jump**: Swipe up
- **Slide**: Swipe down

## Technical Implementation

The game is built using React with TypeScript and HTML5 Canvas for rendering. Key components include:

- Game engine with physics simulation
- Character controller with animations
- Procedurally generated obstacles
- Parallax background with animated elements
- Collision detection system
- Local storage for saving game progress and scores

## Getting Started

1. Clone the repository
2. Install dependencies: `npm install`
3. Start development server: `npm run dev`
4. Open your browser to the local development URL

## Building for Production

```
npm run build
```

This will create optimized files in the `dist` directory ready for deployment.