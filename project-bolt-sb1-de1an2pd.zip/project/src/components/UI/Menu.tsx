import React from 'react';
import { Medal, Play, Info, Settings } from 'lucide-react';
import { getHighScores } from '../../game/storage';

interface MenuProps {
  onStartGame: () => void;
}

export const Menu: React.FC<MenuProps> = ({ onStartGame }) => {
  const highScores = getHighScores();
  const [showInstructions, setShowInstructions] = React.useState(false);
  const [showLeaderboard, setShowLeaderboard] = React.useState(false);

  return (
    <div className="relative w-full max-w-md p-8 text-center">
      <div className="absolute top-0 left-0 w-full h-full bg-slate-900/70 backdrop-blur-sm rounded-2xl -z-10"></div>
      
      <h1 className="text-5xl font-bold mb-2 text-yellow-300 tracking-wider">
        RAHAT RUNS
      </h1>
      <p className="text-lg text-white mb-8">Race through the city!</p>
      
      <div className="flex flex-col gap-4 mb-8">
        <button 
          onClick={onStartGame}
          className="flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white py-3 px-6 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 active:scale-95"
        >
          <Play size={20} />
          Play Now
        </button>
        
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={() => setShowLeaderboard(true)}
            className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-medium transition-all"
          >
            <Medal size={18} />
            Scores
          </button>
          
          <button 
            onClick={() => setShowInstructions(true)}
            className="flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-lg font-medium transition-all"
          >
            <Info size={18} />
            How to Play
          </button>
        </div>
      </div>
      
      {showInstructions && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-4 bg-black/50">
          <div className="bg-slate-800 rounded-xl p-6 w-full max-w-md text-white">
            <h2 className="text-2xl font-bold mb-4 text-yellow-300">How to Play</h2>
            <ul className="text-left mb-6 space-y-2">
              <li>• <strong>Desktop:</strong> Use arrow keys or WASD to move</li>
              <li>• <strong>Jump:</strong> Space / Up Arrow / W</li>
              <li>• <strong>Slide:</strong> Down Arrow / S</li>
              <li>• <strong>Mobile:</strong> Tap left/right side to move, swipe up to jump, down to slide</li>
            </ul>
            <button 
              onClick={() => setShowInstructions(false)}
              className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-lg font-medium"
            >
              Got it!
            </button>
          </div>
        </div>
      )}
      
      {showLeaderboard && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-4 bg-black/50">
          <div className="bg-slate-800 rounded-xl p-6 w-full max-w-md text-white">
            <h2 className="text-2xl font-bold mb-4 text-yellow-300">High Scores</h2>
            {highScores.length > 0 ? (
              <div className="mb-6">
                <div className="grid grid-cols-2 font-semibold mb-2 border-b border-gray-700 pb-2">
                  <div className="text-left">Name</div>
                  <div className="text-right">Score</div>
                </div>
                {highScores.map((score, index) => (
                  <div key={index} className="grid grid-cols-2 py-1">
                    <div className="text-left">{score.name}</div>
                    <div className="text-right">{score.score}</div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mb-6">No high scores yet. Start playing!</p>
            )}
            <button 
              onClick={() => setShowLeaderboard(false)}
              className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-lg font-medium"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};