import React from 'react';
import { Heart } from 'lucide-react';

interface GameHUDProps {
  score: number;
  health: number;
}

export const GameHUD: React.FC<GameHUDProps> = ({ score, health }) => {
  return (
    <div className="absolute top-0 left-0 w-full p-4 flex justify-between items-center">
      <div className="bg-slate-800/70 backdrop-blur-sm text-white px-3 py-1 rounded-lg flex gap-1">
        {Array.from({ length: 3 }).map((_, index) => (
          <Heart
            key={index}
            size={20}
            className={index < health ? "text-red-500 fill-red-500" : "text-gray-500"}
          />
        ))}
      </div>
      
      <div className="bg-slate-800/70 backdrop-blur-sm text-white px-3 py-1 rounded-lg">
        <span className="font-medium">Score:</span> {score}
      </div>
    </div>
  );
};