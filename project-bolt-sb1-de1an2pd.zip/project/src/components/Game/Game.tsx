import React, { useEffect, useRef } from 'react';
import { useGameEngine } from '../../game/useGameEngine';
import { Pause, Play, X } from 'lucide-react';
import { GameHUD } from '../UI/GameHUD';
import { saveScore } from '../../game/storage';

interface GameProps {
  gameState: 'playing' | 'paused';
  onPause: () => void;
  onResume: () => void;
  onExit: () => void;
}

const Game: React.FC<GameProps> = ({ gameState, onPause, onResume, onExit }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameContainer = useRef<HTMLDivElement>(null);
  
  const { 
    isGameOver,
    score, 
    distance,
    health,
    handleKeyDown,
    handleKeyUp,
    handleTouchStart,
    handleTouchMove,
    handleTouchEnd,
    restartGame
  } = useGameEngine(canvasRef, gameState === 'playing');

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleKeyDown, handleKeyUp]);

  useEffect(() => {
    if (isGameOver) {
      saveScore({ name: "Player", score, distance });
    }
  }, [isGameOver, score, distance]);

  return (
    <div 
      ref={gameContainer}
      className="relative w-full max-w-5xl border-4 border-slate-900 rounded-lg overflow-hidden shadow-2xl"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <canvas 
        ref={canvasRef} 
        width={1024} 
        height={576} 
        className="block w-full h-auto bg-sky-300"
      />
      
      <GameHUD score={score} health={health} />
      
      <div className="absolute top-4 right-4 flex gap-2">
        {gameState === 'playing' ? (
          <button 
            onClick={onPause}
            className="bg-slate-800/70 hover:bg-slate-900/90 p-2 rounded-lg text-white transition-colors"
          >
            <Pause size={20} />
          </button>
        ) : (
          <button 
            onClick={onResume}
            className="bg-slate-800/70 hover:bg-slate-900/90 p-2 rounded-lg text-white transition-colors"
          >
            <Play size={20} />
          </button>
        )}
        
        <button 
          onClick={onExit}
          className="bg-red-600/70 hover:bg-red-700/90 p-2 rounded-lg text-white transition-colors"
        >
          <X size={20} />
        </button>
      </div>
      
      {gameState === 'paused' && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/60">
          <div className="bg-slate-800 rounded-xl p-6 text-center">
            <h2 className="text-2xl font-bold mb-4 text-yellow-300">Game Paused</h2>
            <div className="flex gap-3">
              <button 
                onClick={onResume}
                className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg font-medium"
              >
                Resume
              </button>
              <button 
                onClick={onExit}
                className="bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg font-medium"
              >
                Exit
              </button>
            </div>
          </div>
        </div>
      )}
      
      {isGameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/70">
          <div className="bg-slate-800 rounded-xl p-6 text-center">
            <h2 className="text-2xl font-bold mb-2 text-yellow-300">Game Over</h2>
            <p className="text-white mb-1">Score: {score}</p>
            <p className="text-white mb-4">Distance: {distance}m</p>
            <div className="flex gap-3">
              <button 
                onClick={restartGame}
                className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg font-medium"
              >
                Play Again
              </button>
              <button 
                onClick={onExit}
                className="bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg font-medium"
              >
                Menu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Game;