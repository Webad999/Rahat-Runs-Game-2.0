const AudioFiles = {
  jump: new Audio(),
  hit: new Audio(),
  collect: new Audio(),
  gameover: new Audio(),
  bgm: new Audio(),
};

// Placeholder for actual audio URLs
const AudioSources = {
  jump: 'https://assets.mixkit.co/active_storage/sfx/2661/2661-preview.mp3',
  hit: 'https://assets.mixkit.co/active_storage/sfx/957/957-preview.mp3',
  collect: 'https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3',
  gameover: 'https://assets.mixkit.co/active_storage/sfx/1954/1954-preview.mp3',
  bgm: 'https://assets.mixkit.co/active_storage/sfx/5-preview.mp3'
};

export function loadAudio() {
  // Set up audio files
  Object.keys(AudioSources).forEach(key => {
    AudioFiles[key as keyof typeof AudioFiles].src = AudioSources[key as keyof typeof AudioSources];
    AudioFiles[key as keyof typeof AudioFiles].load();
  });
  
  // Configure background music to loop
  AudioFiles.bgm.loop = true;
  AudioFiles.bgm.volume = 0.5; // Set lower volume for background music
}

export function playSound(
  name: keyof typeof AudioFiles, 
  loop: boolean = false, 
  volume: number = 1.0
) {
  // Create a new Audio instance each time for sound effects to allow overlapping
  if (name !== 'bgm') {
    const sound = new Audio(AudioSources[name]);
    sound.volume = volume;
    sound.play();
  } else {
    // For background music, use the existing instance
    if (loop) {
      AudioFiles.bgm.currentTime = 0;
      AudioFiles.bgm.play().catch(e => console.log('Audio play failed:', e));
    } else {
      AudioFiles.bgm.pause();
    }
  }
}

export function stopSound(name: keyof typeof AudioFiles) {
  AudioFiles[name].pause();
  AudioFiles[name].currentTime = 0;
}

export function pauseAllSounds() {
  Object.values(AudioFiles).forEach(audio => {
    audio.pause();
  });
}