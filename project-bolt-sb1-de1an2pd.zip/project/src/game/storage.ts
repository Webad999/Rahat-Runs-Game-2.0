interface Score {
  name: string;
  score: number;
  distance: number;
  date?: string;
}

const STORAGE_KEY = 'rahat-runs-scores';

export function saveScore(score: Score): void {
  // Add timestamp
  const scoreWithDate = {
    ...score,
    date: new Date().toISOString()
  };
  
  try {
    // Get existing scores
    const scores = getHighScores();
    
    // Add new score
    scores.push(scoreWithDate);
    
    // Sort by score (descending)
    scores.sort((a, b) => b.score - a.score);
    
    // Keep only top 10 scores
    const topScores = scores.slice(0, 10);
    
    // Save to local storage
    localStorage.setItem(STORAGE_KEY, JSON.stringify(topScores));
    
  } catch (error) {
    console.error('Error saving score:', error);
  }
}

export function getHighScores(): Score[] {
  try {
    const scores = localStorage.getItem(STORAGE_KEY);
    return scores ? JSON.parse(scores) : [];
  } catch (error) {
    console.error('Error getting scores:', error);
    return [];
  }
}

export function clearScores(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('Error clearing scores:', error);
  }
}

export function saveGameProgress(progress: any): void {
  try {
    localStorage.setItem('rahat-runs-progress', JSON.stringify(progress));
  } catch (error) {
    console.error('Error saving game progress:', error);
  }
}

export function loadGameProgress(): any {
  try {
    const progress = localStorage.getItem('rahat-runs-progress');
    return progress ? JSON.parse(progress) : null;
  } catch (error) {
    console.error('Error loading game progress:', error);
    return null;
  }
}