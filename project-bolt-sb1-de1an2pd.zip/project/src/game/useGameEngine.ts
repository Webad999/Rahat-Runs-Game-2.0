import { useCallback, useEffect, useRef, useState } from 'react';
import { Character } from './character';
import { Background } from './background';
import { ObstacleManager } from './obstacles';
import { checkCollision } from './collisions';
import { loadAudio, playSound } from './audio';

export const useGameEngine = (
  canvasRef: React.RefObject<HTMLCanvasElement>,
  isPlaying: boolean
) => {
  const [score, setScore] = useState(0);
  const [distance, setDistance] = useState(0);
  const [health, setHealth] = useState(3);
  const [isGameOver, setIsGameOver] = useState(false);
  
  const gameLoopRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);
  const characterRef = useRef<Character | null>(null);
  const backgroundRef = useRef<Background | null>(null);
  const obstacleManagerRef = useRef<ObstacleManager | null>(null);
  const worldOffsetRef = useRef(0);
  const inputStateRef = useRef({
    left: false,
    right: false,
    jump: false,
    slide: false,
  });
  
  // Touch controls
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);
  
  const initGame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Initialize game objects
    characterRef.current = new Character(canvas.width, canvas.height);
    backgroundRef.current = new Background(canvas.width, canvas.height);
    obstacleManagerRef.current = new ObstacleManager(canvas.width, canvas.height);
    worldOffsetRef.current = 0;
    
    // Center the character horizontally
    if (characterRef.current) {
      characterRef.current.position.x = canvas.width * 0.3; // Position at 30% of screen width
    }
    
    // Load audio
    loadAudio();
    
    // Reset game state
    setScore(0);
    setDistance(0);
    setHealth(3);
    setIsGameOver(false);
    lastTimeRef.current = 0;
  }, [canvasRef]);
  
  const gameLoop = useCallback((timestamp: number) => {
    if (!characterRef.current || !backgroundRef.current || !obstacleManagerRef.current) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Calculate delta time in seconds
    const deltaTime = (timestamp - lastTimeRef.current) / 1000;
    lastTimeRef.current = timestamp;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Handle inputs
    const inputState = inputStateRef.current;
    characterRef.current.handleInput(inputState, deltaTime);
    
    // Update character
    characterRef.current.update(deltaTime);
    
    // Calculate world movement based on character velocity
    const worldSpeed = characterRef.current.velocity.x;
    worldOffsetRef.current += worldSpeed * deltaTime;
    
    // Update background with world movement
    backgroundRef.current.update(deltaTime, worldSpeed);
    
    // Update obstacles with world movement
    const newObstacles = obstacleManagerRef.current.update(
      deltaTime, 
      worldSpeed,
      characterRef.current.position.x
    );
    
    if (newObstacles) {
      setScore(prevScore => prevScore + 10);
    }
    
    // Update distance based on world movement
    setDistance(prev => {
      const newDistance = prev + worldSpeed * deltaTime * 0.5;
      return Math.floor(newDistance);
    });
    
    // Check collisions
    const collisionResult = checkCollision(
      characterRef.current,
      [...obstacleManagerRef.current.obstacles, ...obstacleManagerRef.current.collectibles]
    );
    
    if (collisionResult.collision && !characterRef.current.isInvulnerable) {
      characterRef.current.hit();
      playSound('hit');
      
      setHealth(prev => {
        const newHealth = prev - 1;
        if (newHealth <= 0) {
          setIsGameOver(true);
          playSound('gameover');
          return 0;
        }
        return newHealth;
      });
    }
    
    if (collisionResult.collectible) {
      setScore(prevScore => prevScore + 50);
      playSound('collect');
    }
    
    // Render game world
    backgroundRef.current.render(ctx);
    obstacleManagerRef.current.render(ctx);
    characterRef.current.render(ctx);
    
    // Continue game loop if not game over
    if (!isGameOver) {
      gameLoopRef.current = requestAnimationFrame(gameLoop);
    }
  }, [canvasRef, isGameOver]);
  
  // Initialize game
  useEffect(() => {
    initGame();
    
    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    };
  }, [initGame]);
  
  // Start/stop game loop based on isPlaying prop
  useEffect(() => {
    if (isPlaying && !isGameOver) {
      lastTimeRef.current = performance.now();
      gameLoopRef.current = requestAnimationFrame(gameLoop);
      playSound('bgm', true);
    } else {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    }
    
    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    };
  }, [isPlaying, isGameOver, gameLoop]);
  
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowLeft':
      case 'a':
      case 'A':
        inputStateRef.current.left = true;
        break;
      case 'ArrowRight':
      case 'd':
      case 'D':
        inputStateRef.current.right = true;
        break;
      case 'ArrowUp':
      case 'w':
      case 'W':
      case ' ':
        inputStateRef.current.jump = true;
        break;
      case 'ArrowDown':
      case 's':
      case 'S':
        inputStateRef.current.slide = true;
        break;
    }
  }, []);
  
  const handleKeyUp = useCallback((e: KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowLeft':
      case 'a':
      case 'A':
        inputStateRef.current.left = false;
        break;
      case 'ArrowRight':
      case 'd':
      case 'D':
        inputStateRef.current.right = false;
        break;
      case 'ArrowUp':
      case 'w':
      case 'W':
      case ' ':
        inputStateRef.current.jump = false;
        break;
      case 'ArrowDown':
      case 's':
      case 'S':
        inputStateRef.current.slide = false;
        break;
    }
  }, []);
  
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 0) return;
    
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    
    // Check which side of the screen was touched
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const halfWidth = canvas.clientWidth / 2;
    
    if (touchStartX.current < halfWidth) {
      inputStateRef.current.left = true;
    } else {
      inputStateRef.current.right = true;
    }
  }, [canvasRef]);
  
  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 0 || touchStartX.current === null || touchStartY.current === null) return;
    
    const touchX = e.touches[0].clientX;
    const touchY = e.touches[0].clientY;
    
    const deltaX = touchX - touchStartX.current;
    const deltaY = touchY - touchStartY.current;
    
    // Detect swipe up (jump)
    if (deltaY < -50) {
      inputStateRef.current.jump = true;
      touchStartY.current = touchY;
    }
    
    // Detect swipe down (slide)
    if (deltaY > 50) {
      inputStateRef.current.slide = true;
      touchStartY.current = touchY;
    }
  }, []);
  
  const handleTouchEnd = useCallback(() => {
    inputStateRef.current.left = false;
    inputStateRef.current.right = false;
    inputStateRef.current.jump = false;
    inputStateRef.current.slide = false;
    
    touchStartX.current = null;
    touchStartY.current = null;
  }, []);
  
  const restartGame = useCallback(() => {
    initGame();
    if (isPlaying) {
      lastTimeRef.current = performance.now();
      gameLoopRef.current = requestAnimationFrame(gameLoop);
    }
  }, [initGame, gameLoop, isPlaying]);
  
  return {
    score,
    distance,
    health,
    isGameOver,
    handleKeyDown,
    handleKeyUp,
    handleTouchStart,
    handleTouchMove,
    handleTouchEnd,
    restartGame
  };
};