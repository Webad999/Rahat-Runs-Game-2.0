import React from 'react';

export class Character {
  width: number = 50;
  height: number = 80;
  position: { x: number; y: number };
  velocity: { x: number; y: number };
  gravity: number = 1500;
  jumpForce: number = -700;
  maxSpeed: number = 400;
  acceleration: number = 1500;
  friction: number = 0.8;
  isJumping: boolean = false;
  isDoubleJumping: boolean = false;
  isSliding: boolean = false;
  jumpPressed: boolean = false;
  canvasWidth: number;
  canvasHeight: number;
  isInvulnerable: boolean = false;
  invulnerableTimer: number = 0;
  invulnerableDuration: number = 1.5;
  
  frame: number = 0;
  frameCount: number = 8;
  frameDelay: number = 0.1;
  frameTimer: number = 0;
  animationState: 'idle' | 'run' | 'jump' | 'fall' | 'slide' | 'hit' = 'idle';
  
  bodyColor: string = '#3366ff';
  outlineColor: string = '#1a3380';
  
  constructor(canvasWidth: number, canvasHeight: number) {
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    
    // Start position - always centered horizontally
    this.position = {
      x: canvasWidth * 0.3,
      y: canvasHeight * 0.7
    };
    
    // Initial velocity - constant forward motion
    this.velocity = {
      x: 300,
      y: 0
    };
  }
  
  handleInput(
    inputState: { left: boolean; right: boolean; jump: boolean; slide: boolean },
    deltaTime: number
  ) {
    // Maintain constant forward motion with speed variations
    const baseSpeed = 300;
    const speedVariation = 100;
    
    if (inputState.left) {
      this.velocity.x = Math.max(baseSpeed - speedVariation, this.velocity.x - this.acceleration * deltaTime);
    } else if (inputState.right) {
      this.velocity.x = Math.min(baseSpeed + speedVariation, this.velocity.x + this.acceleration * deltaTime);
    } else {
      // Return to base speed
      if (this.velocity.x > baseSpeed) {
        this.velocity.x = Math.max(baseSpeed, this.velocity.x - this.acceleration * deltaTime);
      } else if (this.velocity.x < baseSpeed) {
        this.velocity.x = Math.min(baseSpeed, this.velocity.x + this.acceleration * deltaTime);
      }
    }
    
    // Jump control with better feel
    if (inputState.jump && !this.jumpPressed) {
      this.jumpPressed = true;
      
      if (!this.isJumping) {
        this.velocity.y = this.jumpForce;
        this.isJumping = true;
        this.isDoubleJumping = false;
      } else if (!this.isDoubleJumping) {
        this.velocity.y = this.jumpForce * 0.8;
        this.isDoubleJumping = true;
      }
    }
    
    if (!inputState.jump) {
      this.jumpPressed = false;
    }
    
    // Slide control
    this.isSliding = inputState.slide && !this.isJumping;
  }
  
  update(deltaTime: number) {
    // Apply gravity with terminal velocity
    const terminalVelocity = 1000;
    this.velocity.y = Math.min(
      this.velocity.y + this.gravity * deltaTime,
      terminalVelocity
    );
    
    // Update vertical position only - horizontal position stays fixed
    this.position.y += this.velocity.y * deltaTime;
    
    // Keep character centered horizontally
    this.position.x = this.canvasWidth * 0.3;
    
    // Floor collision
    const floorY = this.canvasHeight * 0.75;
    const adjustedHeight = this.isSliding ? this.height / 2 : this.height / 2;
    
    if (this.position.y >= floorY - adjustedHeight) {
      this.position.y = floorY - adjustedHeight;
      this.velocity.y = 0;
      this.isJumping = false;
      this.isDoubleJumping = false;
    }
    
    // Update animation state
    if (this.isSliding) {
      this.animationState = 'slide';
      this.height = 40;
    } else if (this.velocity.y < 0) {
      this.animationState = 'jump';
      this.height = 80;
    } else if (this.velocity.y > 100) {
      this.animationState = 'fall';
      this.height = 80;
    } else {
      this.animationState = 'run';
      this.height = 80;
    }
    
    // Update animation frame
    this.frameTimer += deltaTime;
    if (this.frameTimer >= this.frameDelay) {
      this.frame = (this.frame + 1) % this.frameCount;
      this.frameTimer = 0;
    }
    
    // Update invulnerability
    if (this.isInvulnerable) {
      this.invulnerableTimer += deltaTime;
      if (this.invulnerableTimer >= this.invulnerableDuration) {
        this.isInvulnerable = false;
        this.invulnerableTimer = 0;
      }
    }
  }
  
  render(ctx: CanvasRenderingContext2D) {
    ctx.save();
    
    // Flash effect when invulnerable
    if (this.isInvulnerable && Math.floor(Date.now() / 100) % 2 === 0) {
      ctx.globalAlpha = 0.5;
    }
    
    // Draw character based on animation state
    if (this.animationState === 'slide') {
      this.renderSlide(ctx);
    } else {
      this.renderCharacter(ctx);
    }
    
    ctx.restore();
  }
  
  renderCharacter(ctx: CanvasRenderingContext2D) {
    const x = this.position.x;
    const y = this.position.y;
    
    // Body
    ctx.fillStyle = this.bodyColor;
    ctx.strokeStyle = this.outlineColor;
    ctx.lineWidth = 2;
    
    // Animate up/down slightly based on frame
    const bounceOffset = (this.animationState === 'run') 
      ? Math.sin(this.frame / this.frameCount * Math.PI * 2) * 3 
      : 0;
    
    // Draw body (rounded rectangle)
    this.roundRect(
      ctx, 
      x - this.width / 2, 
      y - this.height / 2 + bounceOffset, 
      this.width, 
      this.height, 
      10
    );
    
    // Draw eyes
    const eyeSize = 8;
    const eyeY = y - 15 + bounceOffset;
    
    ctx.fillStyle = 'white';
    ctx.beginPath();
    ctx.arc(x - 10, eyeY, eyeSize, 0, Math.PI * 2);
    ctx.arc(x + 10, eyeY, eyeSize, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = 'black';
    const pupilOffset = this.velocity.x > 0 ? 2 : -2;
    ctx.beginPath();
    ctx.arc(x - 10 + pupilOffset, eyeY, eyeSize / 2, 0, Math.PI * 2);
    ctx.arc(x + 10 + pupilOffset, eyeY, eyeSize / 2, 0, Math.PI * 2);
    ctx.fill();
    
    // Draw mouth
    if (this.animationState === 'jump') {
      // Surprised mouth for jumping
      ctx.beginPath();
      ctx.arc(x, y + 10 + bounceOffset, 5, 0, Math.PI * 2);
      ctx.fillStyle = 'black';
      ctx.fill();
    } else {
      // Smile
      ctx.beginPath();
      ctx.arc(x, y + 5 + bounceOffset, 10, 0, Math.PI);
      ctx.strokeStyle = 'black';
      ctx.stroke();
    }
    
    // Draw legs (animated)
    const legOffset = (this.animationState === 'run') 
      ? Math.sin(this.frame / this.frameCount * Math.PI * 2) * 10 
      : 0;
    
    ctx.lineWidth = 4;
    ctx.strokeStyle = this.outlineColor;
    
    // Left leg
    ctx.beginPath();
    ctx.moveTo(x - 15, y + this.height / 2 - 5);
    ctx.lineTo(x - 15 - legOffset, y + this.height / 2 + 15);
    ctx.stroke();
    
    // Right leg
    ctx.beginPath();
    ctx.moveTo(x + 15, y + this.height / 2 - 5);
    ctx.lineTo(x + 15 + legOffset, y + this.height / 2 + 15);
    ctx.stroke();
    
    // Arms for jumping or falling
    if (this.animationState === 'jump' || this.animationState === 'fall') {
      const armOffset = this.animationState === 'jump' ? -10 : 10;
      
      // Left arm
      ctx.beginPath();
      ctx.moveTo(x - 20, y);
      ctx.lineTo(x - 30, y + armOffset);
      ctx.stroke();
      
      // Right arm
      ctx.beginPath();
      ctx.moveTo(x + 20, y);
      ctx.lineTo(x + 30, y + armOffset);
      ctx.stroke();
    }
  }
  
  renderSlide(ctx: CanvasRenderingContext2D) {
    const x = this.position.x;
    const y = this.position.y;
    
    // Sliding character (more horizontal)
    ctx.fillStyle = this.bodyColor;
    ctx.strokeStyle = this.outlineColor;
    ctx.lineWidth = 2;
    
    // Body (elongated horizontally)
    this.roundRect(
      ctx, 
      x - this.width * 1.2, 
      y - this.height / 2, 
      this.width * 2.4, 
      this.height, 
      10
    );
    
    // Eyes
    const eyeY = y - 5;
    ctx.fillStyle = 'white';
    ctx.beginPath();
    ctx.arc(x + 20, eyeY, 7, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = 'black';
    ctx.beginPath();
    ctx.arc(x + 22, eyeY, 3, 0, Math.PI * 2);
    ctx.fill();
    
    // Sliding effect lines
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.beginPath();
    ctx.moveTo(x - 40, y + this.height / 2 - 5);
    ctx.lineTo(x - 60, y + this.height / 2 - 5);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(x - 30, y + this.height / 2);
    ctx.lineTo(x - 45, y + this.height / 2);
    ctx.stroke();
  }
  
  hit() {
    if (!this.isInvulnerable) {
      this.isInvulnerable = true;
      this.invulnerableTimer = 0;
      this.animationState = 'hit';
      this.velocity.y = -300; // Small upward bounce
    }
  }
  
  private roundRect(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    radius: number
  ) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
}