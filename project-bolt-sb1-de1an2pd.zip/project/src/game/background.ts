export class Background {
  private canvasWidth: number;
  private canvasHeight: number;
  private layers: BackgroundLayer[] = [];
  private cloudPositions: { x: number; y: number; speed: number; width: number; height: number }[] = [];
  private buildingPositions: Building[] = [];
  private skyGradientColors: string[] = [
    'rgb(135, 206, 235)', // Sky blue
    'rgb(100, 180, 255)', // Deeper blue
    'rgb(80, 150, 255)'   // Evening blue
  ];
  private currentDayTime: number = 0; // 0-1 range representing time of day
  private dayLength: number = 120; // seconds for a full day cycle
  
  constructor(canvasWidth: number, canvasHeight: number) {
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    
    // Create parallax layers with fixed positions
    this.layers = [
      { 
        offset: 0, 
        speed: 0.05, 
        color: '#5080bf', // Distant mountains
        yPos: this.canvasHeight * 0.65
      },
      { 
        offset: 0, 
        speed: 0.1, 
        color: '#3a7a47', // Hills
        yPos: this.canvasHeight * 0.7
      },
      { 
        offset: 0, 
        speed: 0.3, 
        color: '#496a2d', // Closer hills
        yPos: this.canvasHeight * 0.75
      },
      { 
        offset: 0, 
        speed: 0.5, 
        color: '#228630', // Ground
        yPos: this.canvasHeight * 0.75
      }
    ];
    
    // Generate clouds with fixed initial positions
    for (let i = 0; i < 20; i++) {
      this.cloudPositions.push({
        x: (i / 20) * this.canvasWidth * 3,
        y: Math.random() * this.canvasHeight * 0.4,
        speed: 0.2 + Math.random() * 0.3,
        width: 60 + Math.random() * 100,
        height: 40 + Math.random() * 30
      });
    }
    
    // Generate buildings with fixed spacing
    const buildingCount = 15;
    const buildingSpacing = this.canvasWidth / 3;
    
    for (let i = 0; i < buildingCount; i++) {
      const x = i * buildingSpacing;
      const height = 100 + Math.random() * 150;
      const width = 80 + Math.random() * 120;
      const color = this.getRandomBuildingColor();
      const windows = this.generateWindows(width, height);
      
      this.buildingPositions.push({
        x,
        height,
        width,
        color,
        windows
      });
    }
  }
  
  update(deltaTime: number, playerSpeed: number) {
    // Update layer positions with proper wrapping
    this.layers.forEach(layer => {
      layer.offset -= playerSpeed * layer.speed * deltaTime;
      
      // Wrap around when a full screen width is passed
      if (layer.offset <= -this.canvasWidth) {
        layer.offset += this.canvasWidth;
      }
    });
    
    // Update cloud positions with proper wrapping
    this.cloudPositions.forEach(cloud => {
      cloud.x -= cloud.speed * playerSpeed * deltaTime;
      
      // Wrap around when off screen
      if (cloud.x + cloud.width < 0) {
        cloud.x = this.canvasWidth;
        cloud.y = Math.random() * this.canvasHeight * 0.4;
      }
    });
    
    // Update building positions with proper wrapping
    this.buildingPositions.forEach(building => {
      building.x -= playerSpeed * 0.4 * deltaTime;
      
      // Wrap around when off screen
      if (building.x + building.width < 0) {
        // Find rightmost building
        const rightmostX = Math.max(...this.buildingPositions.map(b => b.x + b.width));
        building.x = rightmostX + Math.random() * 100; // Add some random spacing
        building.height = 100 + Math.random() * 150;
        building.width = 80 + Math.random() * 120;
        building.color = this.getRandomBuildingColor();
        building.windows = this.generateWindows(building.width, building.height);
      }
    });
    
    // Update day-night cycle
    this.currentDayTime += deltaTime / this.dayLength;
    if (this.currentDayTime >= 1) {
      this.currentDayTime = 0;
    }
  }
  
  render(ctx: CanvasRenderingContext2D) {
    // Draw sky gradient based on time of day
    const gradient = ctx.createLinearGradient(0, 0, 0, this.canvasHeight * 0.8);
    
    // Calculate sky colors based on time of day
    const skyColors = this.getSkyGradientColors(this.currentDayTime);
    gradient.addColorStop(0, skyColors[0]);
    gradient.addColorStop(0.5, skyColors[1]);
    gradient.addColorStop(1, skyColors[2]);
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);
    
    // Draw sun or moon
    this.drawSunOrMoon(ctx);
    
    // Draw clouds
    this.cloudPositions.forEach(cloud => {
      this.drawCloud(ctx, cloud.x, cloud.y, cloud.width, cloud.height);
    });
    
    // Draw buildings
    this.buildingPositions.forEach(building => {
      this.drawBuilding(ctx, building);
    });
    
    // Draw parallax layers (mountains & ground)
    this.layers.forEach(layer => {
      // Draw the layer at its current position
      this.drawLayer(ctx, layer, layer.offset);
      
      // Draw the same layer again to create infinite scrolling
      this.drawLayer(ctx, layer, layer.offset + this.canvasWidth);
    });
    
    // Draw ground
    ctx.fillStyle = '#3c6e24';
    ctx.fillRect(0, this.canvasHeight * 0.75, this.canvasWidth, this.canvasHeight * 0.25);
    
    // Draw ground details
    this.drawGroundDetails(ctx);
  }
  
  private drawLayer(ctx: CanvasRenderingContext2D, layer: BackgroundLayer, xPosition: number) {
    ctx.fillStyle = layer.color;
    
    // Draw mountain or hill shape
    ctx.beginPath();
    ctx.moveTo(xPosition, this.canvasHeight);
    
    if (layer.speed < 0.1) {
      // Distant mountains
      this.drawMountainSilhouette(ctx, xPosition, layer.yPos);
    } else {
      // Hills
      this.drawHillSilhouette(ctx, xPosition, layer.yPos);
    }
    
    ctx.lineTo(xPosition + this.canvasWidth, this.canvasHeight);
    ctx.closePath();
    ctx.fill();
  }
  
  private drawMountainSilhouette(ctx: CanvasRenderingContext2D, startX: number, yPos: number) {
    const width = this.canvasWidth;
    const height = this.canvasHeight - yPos;
    
    // Draw a jagged mountain silhouette
    let x = startX;
    const peakCount = 5;
    const segmentWidth = width / peakCount;
    
    ctx.moveTo(x, this.canvasHeight);
    
    for (let i = 0; i < peakCount; i++) {
      const peakHeight = yPos - Math.random() * height * 0.4;
      const peakX = x + segmentWidth / 2;
      
      ctx.quadraticCurveTo(
        peakX - segmentWidth / 4, 
        yPos + height * 0.2, 
        peakX, 
        peakHeight
      );
      
      ctx.quadraticCurveTo(
        peakX + segmentWidth / 4, 
        yPos + height * 0.2, 
        x + segmentWidth, 
        yPos
      );
      
      x += segmentWidth;
    }
  }
  
  private drawHillSilhouette(ctx: CanvasRenderingContext2D, startX: number, yPos: number) {
    const width = this.canvasWidth;
    
    // Draw a smooth hill silhouette
    let x = startX;
    const hillCount = 3;
    const segmentWidth = width / hillCount;
    
    ctx.moveTo(x, this.canvasHeight);
    
    for (let i = 0; i < hillCount; i++) {
      ctx.quadraticCurveTo(
        x + segmentWidth / 2, 
        yPos - 40 - Math.random() * 30, 
        x + segmentWidth, 
        yPos
      );
      
      x += segmentWidth;
    }
  }
  
  private drawCloud(
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    width: number, 
    height: number
  ) {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    
    // Draw a fluffy cloud made of circles
    const radius = height / 2;
    
    // Draw multiple overlapping circles to create a cloud shape
    ctx.beginPath();
    ctx.arc(x + radius, y + radius, radius, 0, Math.PI * 2);
    ctx.arc(x + width * 0.25, y + radius * 0.8, radius * 0.8, 0, Math.PI * 2);
    ctx.arc(x + width * 0.5, y + radius * 0.6, radius * 1.1, 0, Math.PI * 2);
    ctx.arc(x + width * 0.75, y + radius * 0.7, radius * 0.9, 0, Math.PI * 2);
    ctx.arc(x + width - radius, y + radius, radius, 0, Math.PI * 2);
    ctx.fill();
  }
  
  private drawBuilding(ctx: CanvasRenderingContext2D, building: Building) {
    const { x, height, width, color, windows } = building;
    
    // Draw building base
    ctx.fillStyle = color;
    ctx.fillRect(x, this.canvasHeight * 0.75 - height, width, height);
    
    // Draw building outline
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, this.canvasHeight * 0.75 - height, width, height);
    
    // Draw windows
    ctx.fillStyle = this.getWindowColor(this.currentDayTime);
    windows.forEach(window => {
      ctx.fillRect(
        x + window.x, 
        this.canvasHeight * 0.75 - height + window.y, 
        window.width, 
        window.height
      );
    });
  }
  
  private drawGroundDetails(ctx: CanvasRenderingContext2D) {
    const groundY = this.canvasHeight * 0.75;
    
    // Draw grass strands
    ctx.strokeStyle = '#4ca832';
    ctx.lineWidth = 2;
    
    for (let i = 0; i < this.canvasWidth; i += 15) {
      const height = 5 + Math.random() * 10;
      
      ctx.beginPath();
      ctx.moveTo(i, groundY);
      ctx.lineTo(i, groundY - height);
      ctx.stroke();
    }
    
    // Draw track/path
    ctx.fillStyle = '#c2b280';
    ctx.fillRect(0, groundY, this.canvasWidth, 15);
    
    // Draw track details
    ctx.strokeStyle = '#a89b6a';
    ctx.setLineDash([15, 10]);
    ctx.beginPath();
    ctx.moveTo(0, groundY + 7);
    ctx.lineTo(this.canvasWidth, groundY + 7);
    ctx.stroke();
    ctx.setLineDash([]);
  }
  
  private drawSunOrMoon(ctx: CanvasRenderingContext2D) {
    const time = this.currentDayTime;
    const radius = 40;
    let x, y;
    
    // Calculate position based on time
    x = this.canvasWidth * 0.2 + (this.canvasWidth * 0.6 * time);
    y = this.canvasHeight * 0.3 + Math.sin(time * Math.PI) * this.canvasHeight * 0.25;
    
    if (time < 0.5) {
      // Draw sun
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
      gradient.addColorStop(0, 'rgba(255, 255, 190, 1)');
      gradient.addColorStop(0.7, 'rgba(255, 255, 0, 1)');
      gradient.addColorStop(1, 'rgba(255, 200, 0, 0)');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
      
      // Draw sun rays
      ctx.strokeStyle = 'rgba(255, 255, 0, 0.4)';
      ctx.lineWidth = 3;
      
      for (let i = 0; i < 12; i++) {
        const angle = i * Math.PI / 6;
        ctx.beginPath();
        ctx.moveTo(
          x + Math.cos(angle) * radius * 1.2,
          y + Math.sin(angle) * radius * 1.2
        );
        ctx.lineTo(
          x + Math.cos(angle) * radius * 2,
          y + Math.sin(angle) * radius * 2
        );
        ctx.stroke();
      }
    } else {
      // Draw moon
      ctx.fillStyle = 'rgba(240, 240, 240, 0.9)';
      ctx.beginPath();
      ctx.arc(x, y, radius * 0.8, 0, Math.PI * 2);
      ctx.fill();
      
      // Draw craters
      ctx.fillStyle = 'rgba(200, 200, 200, 0.5)';
      ctx.beginPath();
      ctx.arc(x - radius * 0.3, y - radius * 0.2, radius * 0.15, 0, Math.PI * 2);
      ctx.arc(x + radius * 0.2, y + radius * 0.3, radius * 0.1, 0, Math.PI * 2);
      ctx.arc(x - radius * 0.1, y + radius * 0.4, radius * 0.12, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  
  private getSkyGradientColors(timeOfDay: number): string[] {
    // Transition between different sky colors based on time of day
    if (timeOfDay < 0.25) {
      // Morning (blend from night to day)
      return [
        this.blendColors('rgb(20, 30, 80)', 'rgb(135, 206, 235)', timeOfDay * 4),
        this.blendColors('rgb(40, 50, 120)', 'rgb(100, 180, 255)', timeOfDay * 4),
        this.blendColors('rgb(60, 70, 140)', 'rgb(80, 150, 255)', timeOfDay * 4)
      ];
    } else if (timeOfDay < 0.75) {
      // Day time (bright blue)
      return [
        'rgb(135, 206, 235)', // Sky blue
        'rgb(100, 180, 255)', // Deeper blue
        'rgb(80, 150, 255)'   // Evening blue
      ];
    } else {
      // Evening (blend from day to night)
      const t = (timeOfDay - 0.75) * 4;
      return [
        this.blendColors('rgb(135, 206, 235)', 'rgb(20, 30, 80)', t),
        this.blendColors('rgb(100, 180, 255)', 'rgb(40, 50, 120)', t),
        this.blendColors('rgb(80, 150, 255)', 'rgb(60, 70, 140)', t)
      ];
    }
  }
  
  private blendColors(color1: string, color2: string, ratio: number): string {
    // Extract RGB components
    const r1 = parseInt(color1.substring(4, color1.indexOf(',')), 10);
    const g1 = parseInt(color1.substring(color1.indexOf(',') + 1, color1.lastIndexOf(',')), 10);
    const b1 = parseInt(color1.substring(color1.lastIndexOf(',') + 1, color1.indexOf(')')), 10);
    
    const r2 = parseInt(color2.substring(4, color2.indexOf(',')), 10);
    const g2 = parseInt(color2.substring(color2.indexOf(',') + 1, color2.lastIndexOf(',')), 10);
    const b2 = parseInt(color2.substring(color2.lastIndexOf(',') + 1, color2.indexOf(')')), 10);
    
    // Blend colors
    const r = Math.round(r1 + (r2 - r1) * ratio);
    const g = Math.round(g1 + (g2 - g1) * ratio);
    const b = Math.round(b1 + (b2 - b1) * ratio);
    
    return `rgb(${r}, ${g}, ${b})`;
  }
  
  private getRandomBuildingColor(): string {
    const colors = [
      '#7e7e7e', // Gray
      '#a67c52', // Brown
      '#8c8c8c', // Light gray
      '#d6d6d6', // Very light gray
      '#b1cbe0'  // Light blue
    ];
    
    return colors[Math.floor(Math.random() * colors.length)];
  }
  
  private getWindowColor(timeOfDay: number): string {
    if (timeOfDay < 0.25 || timeOfDay > 0.75) {
      // Night - bright yellow windows
      return 'rgba(255, 255, 150, 0.8)';
    } else {
      // Day - dark windows with reflection
      return 'rgba(100, 180, 255, 0.6)';
    }
  }
  
  private generateWindows(buildingWidth: number, buildingHeight: number): Window[] {
    const windows: Window[] = [];
    const windowWidth = 10;
    const windowHeight = 15;
    const padding = 15;
    
    const rows = Math.floor((buildingHeight - padding * 2) / (windowHeight + padding));
    const cols = Math.floor((buildingWidth - padding * 2) / (windowWidth + padding));
    
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        // Randomly skip some windows
        if (Math.random() > 0.8) continue;
        
        windows.push({
          x: padding + col * (windowWidth + padding),
          y: padding + row * (windowHeight + padding),
          width: windowWidth,
          height: windowHeight
        });
      }
    }
    
    return windows;
  }
}

interface BackgroundLayer {
  offset: number;
  speed: number;
  color: string;
  yPos: number;
}

interface Window {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface Building {
  x: number;
  height: number;
  width: number;
  color: string;
  windows: Window[];
}