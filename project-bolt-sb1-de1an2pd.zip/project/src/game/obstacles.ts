export class ObstacleManager {
  obstacles: Obstacle[] = [];
  collectibles: Collectible[] = [];
  canvasWidth: number;
  canvasHeight: number;
  nextObstacleDistance: number;
  accumulatedDistance: number = 0;
  level: number = 1;
  
  constructor(canvasWidth: number, canvasHeight: number) {
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    this.nextObstacleDistance = this.getRandomDistance();
  }
  
  update(deltaTime: number, playerSpeed: number, playerX: number): boolean {
    // Calculate distance moved this frame
    const distanceMoved = playerSpeed * deltaTime;
    this.accumulatedDistance += distanceMoved;
    
    let newObstacleAdded = false;
    
    // Add new obstacles as needed
    if (this.accumulatedDistance >= this.nextObstacleDistance) {
      this.addRandomObstacle();
      this.nextObstacleDistance = this.accumulatedDistance + this.getRandomDistance();
      newObstacleAdded = true;
      
      // Occasionally add collectibles
      if (Math.random() < 0.3) {
        this.addRandomCollectible();
      }
    }
    
    // Update obstacle positions
    this.obstacles.forEach(obstacle => {
      obstacle.x -= playerSpeed * deltaTime;
    });
    
    // Update collectible positions
    this.collectibles.forEach(collectible => {
      collectible.x -= playerSpeed * deltaTime;
      
      // Animate collectibles
      collectible.animTimer += deltaTime;
      if (collectible.animTimer >= collectible.animSpeed) {
        collectible.frame = (collectible.frame + 1) % collectible.frameCount;
        collectible.animTimer = 0;
      }
    });
    
    // Remove offscreen obstacles
    this.obstacles = this.obstacles.filter(obstacle => 
      obstacle.x + obstacle.width > -100
    );
    
    // Remove offscreen or collected collectibles
    this.collectibles = this.collectibles.filter(collectible => 
      collectible.x + collectible.width > -50 && !collectible.collected
    );
    
    // Increase level based on distance
    this.level = Math.floor(this.accumulatedDistance / 1000) + 1;
    
    return newObstacleAdded;
  }
  
  render(ctx: CanvasRenderingContext2D) {
    // Render obstacles
    this.obstacles.forEach(obstacle => {
      this.renderObstacle(ctx, obstacle);
    });
    
    // Render collectibles
    this.collectibles.forEach(collectible => {
      this.renderCollectible(ctx, collectible);
    });
  }
  
  private renderObstacle(ctx: CanvasRenderingContext2D, obstacle: Obstacle) {
    switch (obstacle.type) {
      case 'gap':
        this.renderGap(ctx, obstacle);
        break;
      case 'hurdle':
        this.renderHurdle(ctx, obstacle);
        break;
      case 'barrier':
        this.renderBarrier(ctx, obstacle);
        break;
      case 'platform':
        this.renderPlatform(ctx, obstacle);
        break;
    }
  }
  
  private renderGap(ctx: CanvasRenderingContext2D, obstacle: Obstacle) {
    const groundY = this.canvasHeight * 0.75;
    
    // Draw gap
    ctx.fillStyle = 'rgb(50, 50, 90)';
    ctx.fillRect(obstacle.x, groundY, obstacle.width, 100);
    
    // Draw edge details
    ctx.fillStyle = '#3c6e24';
    ctx.fillRect(obstacle.x - 10, groundY, 10, 15);
    ctx.fillRect(obstacle.x + obstacle.width, groundY, 10, 15);
    
    // Draw warning signs
    ctx.fillStyle = '#ffcc00';
    ctx.fillRect(obstacle.x - 25, groundY - 40, 20, 20);
    ctx.fillRect(obstacle.x + obstacle.width + 5, groundY - 40, 20, 20);
    
    ctx.fillStyle = 'black';
    ctx.font = '16px Arial';
    ctx.fillText('!', obstacle.x - 18, groundY - 25);
    ctx.fillText('!', obstacle.x + obstacle.width + 12, groundY - 25);
  }
  
  private renderHurdle(ctx: CanvasRenderingContext2D, obstacle: Obstacle) {
    const groundY = this.canvasHeight * 0.75;
    
    // Draw hurdle body
    ctx.fillStyle = '#a67c52';
    ctx.fillRect(obstacle.x, groundY - obstacle.height, obstacle.width, obstacle.height);
    
    // Draw hurdle details
    ctx.fillStyle = '#8c5a37';
    
    // Horizontal bars
    const barCount = Math.floor(obstacle.height / 15);
    for (let i = 0; i < barCount; i++) {
      ctx.fillRect(obstacle.x, groundY - obstacle.height + (i * 15), obstacle.width, 5);
    }
    
    // Draw supports
    ctx.fillRect(obstacle.x + 5, groundY - obstacle.height, 8, obstacle.height);
    ctx.fillRect(obstacle.x + obstacle.width - 13, groundY - obstacle.height, 8, obstacle.height);
  }
  
  private renderBarrier(ctx: CanvasRenderingContext2D, obstacle: Obstacle) {
    const groundY = this.canvasHeight * 0.75;
    const y = groundY - obstacle.height - obstacle.y;
    
    // Draw barrier
    ctx.fillStyle = '#cc3333';
    this.roundRect(ctx, obstacle.x, y, obstacle.width, obstacle.height, 5);
    
    // Draw stripes
    ctx.fillStyle = 'white';
    const stripeWidth = obstacle.width / 5;
    for (let i = 0; i < 3; i++) {
      ctx.fillRect(
        obstacle.x + stripeWidth + (i * stripeWidth * 2), 
        y + 10, 
        stripeWidth, 
        obstacle.height - 20
      );
    }
  }
  
  private renderPlatform(ctx: CanvasRenderingContext2D, obstacle: Obstacle) {
    const groundY = this.canvasHeight * 0.75;
    const y = groundY - obstacle.height - obstacle.y;
    
    // Draw platform
    ctx.fillStyle = '#6d80c2';
    this.roundRect(ctx, obstacle.x, y, obstacle.width, obstacle.height, 5);
    
    // Draw platform top
    ctx.fillStyle = '#8092d9';
    this.roundRect(ctx, obstacle.x, y, obstacle.width, 10, 5);
    
    // Draw platform supports
    if (obstacle.y > 0) {
      ctx.fillStyle = '#6d80c2';
      ctx.fillRect(obstacle.x + 15, y + obstacle.height, 10, obstacle.y);
      ctx.fillRect(obstacle.x + obstacle.width - 25, y + obstacle.height, 10, obstacle.y);
    }
  }
  
  private renderCollectible(ctx: CanvasRenderingContext2D, collectible: Collectible) {
    const y = collectible.y + Math.sin(collectible.animTimer * 5) * 5; // Floating animation
    
    // Draw glow
    const gradient = ctx.createRadialGradient(
      collectible.x + collectible.width / 2, 
      y + collectible.height / 2, 
      0, 
      collectible.x + collectible.width / 2, 
      y + collectible.height / 2, 
      collectible.width
    );
    gradient.addColorStop(0, 'rgba(255, 215, 0, 0.6)');
    gradient.addColorStop(1, 'rgba(255, 215, 0, 0)');
    
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(
      collectible.x + collectible.width / 2, 
      y + collectible.height / 2, 
      collectible.width / 2 + 10, 
      0, 
      Math.PI * 2
    );
    ctx.fill();
    
    // Draw coin with animation
    ctx.fillStyle = '#ffd700';
    const scaleFactor = 1 - 0.2 * (collectible.frame / collectible.frameCount);
    
    ctx.beginPath();
    ctx.ellipse(
      collectible.x + collectible.width / 2,
      y + collectible.height / 2,
      collectible.width / 2 * scaleFactor,
      collectible.height / 2,
      0,
      0,
      Math.PI * 2
    );
    ctx.fill();
    
    // Draw coin details
    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(
      collectible.x + collectible.width / 2,
      y + collectible.height / 2,
      collectible.width / 3 * scaleFactor,
      collectible.height / 3,
      0,
      0,
      Math.PI * 2
    );
    ctx.stroke();
  }
  
  private addRandomObstacle() {
    const groundY = this.canvasHeight * 0.75;
    const obstacleTypes: ObstacleType[] = ['gap', 'hurdle', 'barrier', 'platform'];
    const type = obstacleTypes[Math.floor(Math.random() * obstacleTypes.length)];
    
    let obstacle: Obstacle = {
      type,
      x: this.canvasWidth + 50, // Start just off screen
      y: 0,
      width: 0,
      height: 0
    };
    
    switch (type) {
      case 'gap':
        obstacle.width = 60 + Math.random() * 40 * Math.min(this.level * 0.3, 2);
        obstacle.height = 100;
        break;
      case 'hurdle':
        obstacle.width = 20 + Math.random() * 10;
        obstacle.height = 40 + Math.random() * 30 * Math.min(this.level * 0.2, 1.5);
        break;
      case 'barrier':
        obstacle.width = 40 + Math.random() * 20;
        obstacle.height = 30 + Math.random() * 20;
        obstacle.y = 70 + Math.random() * 20; // Floating height
        break;
      case 'platform':
        obstacle.width = 100 + Math.random() * 50;
        obstacle.height = 20;
        obstacle.y = 60 + Math.random() * 50; // Platform height
        break;
    }
    
    this.obstacles.push(obstacle);
  }
  
  private addRandomCollectible() {
    const groundY = this.canvasHeight * 0.75;
    
    // Place collectible at various heights
    const y = groundY - 30 - Math.random() * 100;
    
    const collectible: Collectible = {
      x: this.canvasWidth + 100 + Math.random() * 200,
      y,
      width: 30,
      height: 30,
      collected: false,
      frame: 0,
      frameCount: 8,
      animTimer: Math.random(), // Randomize starting frame
      animSpeed: 0.1
    };
    
    this.collectibles.push(collectible);
  }
  
  private getRandomDistance(): number {
    // Obstacles get closer together as level increases
    const baseDist = 500;
    const variance = 300;
    const levelFactor = Math.max(0.5, 1 - this.level * 0.05);
    
    return (baseDist * levelFactor) + Math.random() * variance;
  }
  
  // Helper function for drawing rounded rectangles
  private roundRect(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    radius: number
  ) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    ctx.fill();
  }
}

type ObstacleType = 'gap' | 'hurdle' | 'barrier' | 'platform';

export interface Obstacle {
  type: ObstacleType;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Collectible {
  x: number;
  y: number;
  width: number;
  height: number;
  collected: boolean;
  frame: number;
  frameCount: number;
  animTimer: number;
  animSpeed: number;
}