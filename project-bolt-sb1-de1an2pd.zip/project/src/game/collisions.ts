import { Character } from './character';
import { Obstacle, Collectible } from './obstacles';

interface CollisionResult {
  collision: boolean;
  collectible: boolean;
}

export function checkCollision(
  character: Character, 
  obstacles: (Obstacle | Collectible)[]
): CollisionResult {
  const result: CollisionResult = {
    collision: false,
    collectible: false
  };
  
  // Character hitbox (smaller than visual representation)
  const charHitbox = {
    x: character.position.x - character.width * 0.3,
    y: character.position.y - character.height * 0.3,
    width: character.width * 0.6,
    height: character.height * 0.6
  };
  
  // If sliding, adjust hitbox height
  if (character.isSliding) {
    charHitbox.height = charHitbox.height * 0.5;
    charHitbox.y = character.position.y;
  }
  
  // Check collision with each obstacle
  for (const obstacle of obstacles) {
    // Check if it's a collectible
    if ('collected' in obstacle) {
      const collectible = obstacle as Collectible;
      
      if (!collectible.collected && checkRectCollision(charHitbox, collectible)) {
        collectible.collected = true;
        result.collectible = true;
      }
      
      continue;
    }
    
    // It's a regular obstacle
    const obs = obstacle as Obstacle;
    
    // For gap-type obstacles
    if (obs.type === 'gap') {
      const groundY = 576 * 0.75; // Same value used in other files
      
      // Only check collision if character is at ground level
      if (character.position.y >= groundY - character.height / 2 - 10) {
        const gapHitbox = {
          x: obs.x,
          y: groundY,
          width: obs.width,
          height: 100
        };
        
        if (checkRectCollision(charHitbox, gapHitbox)) {
          result.collision = true;
          break;
        }
      }
    } 
    // For platform-type obstacles
    else if (obs.type === 'platform') {
      const groundY = 576 * 0.75;
      const platformY = groundY - obs.height - obs.y;
      
      // Create platform hitbox
      const platformHitbox = {
        x: obs.x,
        y: platformY,
        width: obs.width,
        height: obs.height
      };
      
      // Check vertical position relative to platform
      const charBottom = character.position.y + charHitbox.height / 2;
      const charFeet = charBottom + 5;
      
      // Check if character is landing on top of platform
      if (character.velocity.y > 0 && // Falling down
          charFeet >= platformY && 
          charFeet <= platformY + 20 && // Within landing range
          character.position.x >= obs.x - charHitbox.width / 2 && 
          character.position.x <= obs.x + obs.width + charHitbox.width / 2) {
        
        // Land on platform
        character.position.y = platformY - charHitbox.height / 2;
        character.velocity.y = 0;
        character.isJumping = false;
        character.isDoubleJumping = false;
      }
      // Check for collision with side or bottom of platform
      else if (checkRectCollision(charHitbox, platformHitbox)) {
        result.collision = true;
        break;
      }
    }
    // For other obstacle types
    else {
      const groundY = 576 * 0.75;
      const obsY = groundY - obs.height - obs.y;
      
      const obsHitbox = {
        x: obs.x,
        y: obsY,
        width: obs.width,
        height: obs.height
      };
      
      if (checkRectCollision(charHitbox, obsHitbox)) {
        result.collision = true;
        break;
      }
    }
  }
  
  return result;
}

function checkRectCollision(
  rect1: { x: number; y: number; width: number; height: number },
  rect2: { x: number; y: number; width: number; height: number }
): boolean {
  // Calculate rectangle edges
  const rect1Left = rect1.x - rect1.width / 2;
  const rect1Right = rect1.x + rect1.width / 2;
  const rect1Top = rect1.y - rect1.height / 2;
  const rect1Bottom = rect1.y + rect1.height / 2;
  
  const rect2Left = rect2.x;
  const rect2Right = rect2.x + rect2.width;
  const rect2Top = rect2.y;
  const rect2Bottom = rect2.y + rect2.height;
  
  // Check for collision
  return (
    rect1Right >= rect2Left &&
    rect1Left <= rect2Right &&
    rect1Bottom >= rect2Top &&
    rect1Top <= rect2Bottom
  );
}