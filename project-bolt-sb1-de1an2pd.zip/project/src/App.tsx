import React, { useState } from 'react';
import { Menu } from './components/UI/Menu';
import Game from './components/Game/Game';

function App() {
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'paused'>('menu');
  
  const startGame = () => {
    setGameState('playing');
  };
  
  const pauseGame = () => {
    setGameState('paused');
  };
  
  const resumeGame = () => {
    setGameState('playing');
  };
  
  const returnToMenu = () => {
    setGameState('menu');
  };

  return (
    <div className="w-full h-screen bg-gradient-to-b from-sky-400 to-blue-600 flex items-center justify-center overflow-hidden">
      {gameState === 'menu' && (
        <Menu onStartGame={startGame} />
      )}
      
      {(gameState === 'playing' || gameState === 'paused') && (
        <Game 
          gameState={gameState} 
          onPause={pauseGame} 
          onResume={resumeGame}
          onExit={returnToMenu}
        />
      )}
    </div>
  );
}

export default App;